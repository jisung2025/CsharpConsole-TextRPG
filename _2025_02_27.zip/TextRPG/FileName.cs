﻿/*
 ---         |  
  | /=\ \ / ---   |/- |/\ /\|
  | \__ / \  \/   |   |-- --|
                      |   \_/ 
using System;
using System.Text;
namespace TextRPG
{
    internal class FileName
    {
        static void Main(string[] args)
        {

            while (true)
            {
                string a = Console.ReadLine();
                for (int i = 30; i > a.Length; i--) ;
                {
                        Console.Write("");            
            public int Lv = 1;
            public int Exp = 0;
            public int Hp = 100;
            public int Mp = 100;
            public int Atk = 10;
            public int WAtk = 0;
            public int Def = 0;
            public int ADef = 0;
            public int Gold = 0;
            public bool ACslime = false;
            public bool ACWolf = false;
            public bool Leather = false;
            public bool Chainmail = false;
            public bool Fullplate = false;
            public bool God = false;
            public bool wood = false;
            public bool stone = false;
            public bool iron = false;
            public bool god = false;
                }
            }
        }
    }
}
 */
